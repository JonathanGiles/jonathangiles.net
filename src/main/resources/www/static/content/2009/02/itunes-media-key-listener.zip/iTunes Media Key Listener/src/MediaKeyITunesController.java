import java.awt.AWTException;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.SwingUtilities;

import org.apache.commons.logging.LogFactory;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.melloware.jintellitype.IntellitypeListener;
import com.melloware.jintellitype.JIntellitype;
import com.melloware.jintellitype.JIntellitypeConstants;

/**
 * Simple program that allows for the media keys on many laptops to control iTunes, even when it
 * doesn't have focus.
 * 
 * @created 20/02/2009
 * @author <a href="http://www.JoGiles.co.nz">Jonathan Giles</a>
 */
public class MediaKeyITunesController implements IntellitypeListener {
	/**
	 * The only means of interacting with this program is through its system tray icon.
	 */
	protected TrayIcon systemTrayIcon;

	/**
	 * The means through which we communicate with itunes - via COM using the Jacob library.
	 */
	private final Dispatch iTunesController;

	public static void main(final String args[]) throws Exception {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				new MediaKeyITunesController();
			}
		});
	}

	public MediaKeyITunesController() {
		// ---- setup iTunes link
		ComThread.InitMTA(true);

		final ActiveXComponent iTunesCom = new ActiveXComponent("iTunes.Application");
		iTunesController = iTunesCom.getObject();

		LogFactory.getLog(this.getClass()).info("iTunes controller initialised: " + iTunesController);

		// ---- Set up listener to media keys
		JIntellitype.getInstance().addIntellitypeListener(this);

		// ---- add shutdown hooks to clean up the JNI code
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				ComThread.Release();
				JIntellitype.getInstance().cleanUp();
			}
		});

		// ---- install the tray icon to show down the bottom of the screen
		installSystemTrayIcon();
	}

	// listen for intellitype play/pause command
	public void onIntellitype(final int aCommand) {
		switch (aCommand) {
			case JIntellitypeConstants.APPCOMMAND_MEDIA_PLAY_PAUSE:
				Dispatch.call(iTunesController, "PlayPause");
				break;
			case JIntellitypeConstants.APPCOMMAND_MEDIA_PREVIOUSTRACK:
				Dispatch.call(iTunesController, "PreviousTrack");
				break;
			case JIntellitypeConstants.APPCOMMAND_MEDIA_NEXTTRACK:
				Dispatch.call(iTunesController, "NextTrack");
				break;
			case JIntellitypeConstants.APPCOMMAND_MEDIA_STOP:
				Dispatch.call(iTunesController, "Stop");
				break;
		}
	}

	private void installSystemTrayIcon() {
		if (SystemTray.isSupported()) {
			// ---- popup menu to show when right-clicking on the system tray icon
			final PopupMenu popup = new PopupMenu();

			final MenuItem exitItem = new MenuItem("Exit");
			exitItem.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(final ActionEvent e) {
					System.exit(0);
				}
			});
			popup.add(exitItem);

			// --- building the tray icon
			final ImageIcon icon = new ImageIcon(this.getClass().getResource("icon.png"));
			systemTrayIcon = new TrayIcon(icon.getImage(), "iTunes Media Key Listener", popup);

			try {
				SystemTray.getSystemTray().add(systemTrayIcon);
			} catch (final AWTException e1) {
				e1.printStackTrace();
			}
		}
	}
}